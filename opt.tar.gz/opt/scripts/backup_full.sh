#!/bin/bash

#Mostrar ayuda
if ["$1" = "-help"] || ["$1" = "--help"]; then
	echo "Uso: $0 ORIGEN DESTINO"
	echo "Realiza un backup del ORIGEN hacia el DESTINO con fecha YYYYMMDD"
	exit 0
fi
#Validar parametros
if [-z "$1"] || [-z "$2"]; then
	echo "Error: faltan parámetros."
	echo "Usá -help para ayuda."
	exit 1
fi
ORIGEN="$1"
DESTINO="$2"
#Validar existencia de origen y destino  
if [! -d "$ORIGEN"]; then 
	echo "Error: origen $ORIGEN no existe."
	exit 1
fi

if [! -d "$DESTINO"]; then
	echo "Error: destino $DESTINO no existe."
	exit 1
fi

#Nombre con fecha
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")_bkp_"$FECHA".tar.gz

#Crear el backup
tar -czf "$DESTINO/$NOMBRE" "$ORIGEN"
echo "Backup creado: $DESTINO/$NOMBRE"
